/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./OrderLineItems/SortDataSet.tsx":
/*!****************************************!*\
  !*** ./OrderLineItems/SortDataSet.tsx ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   sortDataSet: () => (/* binding */ sortDataSet)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react/lib/Styling */ \"@fluentui/react\");\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__);\n\n\n\n\"use strict\";\nvar sortDataSet = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.memo(_ref => {\n  var {\n    dataSet,\n    sequenceColumn,\n    optionSetMetadata,\n    optionSetColumn\n  } = _ref;\n  var [items, setItems] = react__WEBPACK_IMPORTED_MODULE_0__.useState([]);\n  var [colums, setColums] = react__WEBPACK_IMPORTED_MODULE_0__.useState([]);\n  var [selectedRecords, setSelectedRecords] = react__WEBPACK_IMPORTED_MODULE_0__.useState([]);\n  var draggedItem;\n  var theme = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.getTheme)();\n  var dragEnterClass = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.mergeStyles)({\n    backgroundColor: theme.palette.neutralLight\n  });\n  var selection = new _fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Selection({\n    onSelectionChanged: () => {\n      \"use strict\";\n\n      var selectedItems = selection.getSelection();\n      setSelectedRecords(selectedItems);\n    }\n  });\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    dataSet === null || dataSet === void 0 ? void 0 : dataSet.refresh();\n  }, [optionSetMetadata]);\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    \"use strict\";\n\n    setColums(dataSet === null || dataSet === void 0 ? void 0 : dataSet.columns.map(column => {\n      return {\n        name: column.displayName,\n        fieldName: column.name,\n        minWidth: column.visualSizeFactor,\n        Key: column.name,\n        isResizable: true,\n        dataType: column.dataType,\n        showSortIconWhenUnsorted: true\n      };\n    }));\n    var myItems = dataSet === null || dataSet === void 0 ? void 0 : dataSet.sortedRecordIds.map(id => {\n      var record = dataSet.records[id];\n      var attributes = dataSet.columns.map(column => {\n        return {\n          [column.name]: record.getFormattedValue(column.name)\n        };\n      });\n      return Object.assign({\n        Key: record.getRecordId(),\n        raw: record\n      }, ...attributes);\n    });\n    myItems === null || myItems === void 0 ? void 0 : myItems.sort((a, b) => {\n      return Number(a[sequenceColumn.name]) > Number(b[sequenceColumn.name]) ? 1 : -1;\n    });\n    setItems(myItems);\n  }, [dataSet]);\n  //Action of users double-click on a row\n  var onItemInvoke = (item, index, event) => {\n    \"use strict\";\n\n    var pageInput = {\n      pageType: \"entityrecord\",\n      entityName: item.raw.getNamedReference()._etn,\n      entityId: item.raw.getNamedReference()._id //replace with actual ID\n    };\n    var navigationOptions = {\n      target: 2,\n      height: {\n        value: 80,\n        unit: \"%\"\n      },\n      width: {\n        value: 70,\n        unit: \"%\"\n      },\n      position: 1\n    };\n    Xrm.Navigation.navigateTo(pageInput, navigationOptions);\n  };\n  var onDragRowItem = () => {\n    \"use strict\";\n\n    return {\n      canDrop: (dropContext, dragContext) => {\n        return true;\n      },\n      canDrag: item => {\n        return true;\n      },\n      onDragEnter: (item, event) => {\n        // return string is the css classes that will be added to the entering element.\n        return dragEnterClass;\n      },\n      onDragLeave: (item, event) => {\n        return;\n      },\n      onDrop: (item, event) => {\n        if (draggedItem) {\n          insertBeforeItem(item);\n        }\n      },\n      onDragStart: (item, itemIndex, selectedItems, event) => {\n        draggedItem = Array(item);\n      },\n      onDragEnd: (item, event) => {\n        draggedItem = undefined;\n      }\n    };\n  };\n  var insertBeforeItem = item => {\n    \"use strict\";\n\n    var draggedItems = selectedRecords.find(record => record.Key === item.Key) !== undefined ? draggedItem : selectedRecords;\n    var insertIndex = items.indexOf(item);\n    var filteredItems = items.filter(itm => draggedItems.indexOf(itm) === -1);\n    filteredItems.splice(insertIndex, 0, ...draggedItems);\n    setItems(filteredItems);\n  };\n  var renderRow = props => {\n    \"use strict\";\n\n    var _a, _b;\n    var customStyles = {};\n    customStyles.backgroundColor = 'transparent'; // Default background color\n    var value = ((_a = props === null || props === void 0 ? void 0 : props.item) === null || _a === void 0 ? void 0 : _a[optionSetColumn === null || optionSetColumn === void 0 ? void 0 : optionSetColumn.name]) ? (_b = props === null || props === void 0 ? void 0 : props.item) === null || _b === void 0 ? void 0 : _b[optionSetColumn === null || optionSetColumn === void 0 ? void 0 : optionSetColumn.name] : '';\n    if (optionSetMetadata !== undefined && optionSetMetadata.length > 0) {\n      optionSetMetadata.forEach(element => {\n        if (element.label === value) customStyles.backgroundColor = element.color;\n      });\n    }\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.DetailsRow, Object.assign({}, props, {\n      styles: {\n        root: customStyles\n      }\n    }));\n  };\n  var renderItemColumn = (item, index, column) => {\n    \"use strict\";\n\n    var appUrl = Xrm.Utility.getGlobalContext().getCurrentAppUrl();\n    var componentUrl, link;\n    switch (column === null || column === void 0 ? void 0 : column.dataType) {\n      case 'Lookup.Simple':\n        componentUrl = \"&pagetype=entityrecord&etn=\" + item.raw._record.fields[column.fieldName].reference.etn + \"&id=\" + item.raw._record.fields[column.fieldName].reference.id.guid;\n        link = appUrl + componentUrl;\n        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Link, {\n          href: link\n        }, item[column.fieldName]);\n      case 'Lookup.Owner':\n        componentUrl = \"&pagetype=entityrecord&etn=\" + item.raw._record.fields[column.fieldName].reference.etn + \"&id=\" + item.raw._record.fields[column.fieldName].reference.id.guid;\n        link = appUrl + componentUrl;\n        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Link, {\n          href: link\n        }, item[column.fieldName]);\n      default:\n        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, item[column.fieldName]);\n    }\n  };\n  var onClickReorderButton = buttonId => {\n    \"use strict\";\n\n    switch (buttonId) {\n      case \"updateorder\":\n        return () => {\n          \"use strict\";\n\n          if (items) {\n            var promises = [];\n            var _loop = function _loop(i) {\n              promises.push(new Promise((resolve, reject) => {\n                Xrm.WebApi.updateRecord(items[i].raw.getNamedReference()._etn, items[i].raw.getNamedReference()._id, {\n                  [sequenceColumn.name]: i + 1\n                }).then(function success() {\n                  resolve(i);\n                }, function (error) {\n                  reject(error);\n                });\n              }));\n            };\n            for (var i = 0; i < items.length; i++) {\n              _loop(i);\n            }\n            Promise.all(promises).then(() => {\n              dataSet === null || dataSet === void 0 ? void 0 : dataSet.refresh();\n            });\n          }\n        };\n        break;\n      case \"addnew\":\n        return () => {\n          \"use strict\";\n\n          var _a;\n          var totalNumber = (_a = dataSet === null || dataSet === void 0 ? void 0 : dataSet.paging.totalResultCount) !== null && _a !== void 0 ? _a : 0;\n          var parentEntityName = Xrm.Utility.getPageContext().input.entityName;\n          var parentEntityId = Xrm.Utility.getPageContext().input.pageType === \"entityrecord\" ? Xrm.Utility.getPageContext().input.entityId : \"00000000-0000-0000-0000-000000000000\";\n          var pageInput = {\n            pageType: \"entityrecord\",\n            entityName: dataSet.getTargetEntityType(),\n            createFromEntity: {\n              id: parentEntityId,\n              entityType: parentEntityName\n            },\n            data: {\n              [sequenceColumn.name]: totalNumber + 1\n            }\n          };\n          var navigationOptions = {\n            target: 2,\n            height: {\n              value: 80,\n              unit: \"%\"\n            },\n            width: {\n              value: 70,\n              unit: \"%\"\n            },\n            position: 1\n          };\n          Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(() => {\n            dataSet === null || dataSet === void 0 ? void 0 : dataSet.refresh();\n          });\n        };\n        break;\n      case \"delete\":\n        return () => {\n          \"use strict\";\n\n          if ((selectedRecords === null || selectedRecords === void 0 ? void 0 : selectedRecords.length) > 0) {\n            var promises = [];\n            Xrm.Utility.showProgressIndicator(\"Deleting in progress...\");\n            selectedRecords.forEach(record => {\n              promises.push(new Promise((resolve, reject) => {\n                Xrm.WebApi.deleteRecord(record.raw.getNamedReference()._etn, record.raw.getNamedReference()._id).then(function onFullfilled() {\n                  resolve(\"OK\");\n                }, function error(error) {\n                  reject(error);\n                });\n              }));\n            });\n            Promise.all(promises).then(() => {\n              Xrm.Utility.closeProgressIndicator();\n            });\n          }\n        };\n        break;\n      case \"loadall\":\n        return () => {\n          \"use strict\";\n\n          if (dataSet === null || dataSet === void 0 ? void 0 : dataSet.paging.hasNextPage) dataSet.paging.loadNextPage();\n        };\n        break;\n      case \"loadnextpage\":\n        return () => {\n          \"use strict\";\n\n          if (dataSet === null || dataSet === void 0 ? void 0 : dataSet.paging.hasNextPage) dataSet.paging.loadNextPage(true);\n        };\n        break;\n      default:\n        return () => {};\n    }\n  };\n  // Function to calculate row height dynamically based on the first row's height\n  var calculateHeight = () => {\n    \"use strict\";\n\n    var _a;\n    var firstRow = (_a = document.getElementById('aa')) === null || _a === void 0 ? void 0 : _a.querySelector('.ms-DetailsRow');\n    //const rowHeader = document.getElementById('aa')?.querySelector('.ms-DetailsHeader');\n    if (firstRow) {\n      return firstRow.getBoundingClientRect().height * (dataSet === null || dataSet === void 0 ? void 0 : dataSet.paging.pageSize);\n    }\n  };\n  var gridStyles = {\n    contentWrapper: {\n      flex: '1 1 auto',\n      overflow: 'auto',\n      height: calculateHeight()\n    },\n    headerWrapper: {\n      flex: '0 0 auto'\n    },\n    root: {\n      overflowX: 'scroll',\n      selectors: {\n        '& [role=grid]': {\n          display: 'flex',\n          flexDirection: 'column',\n          alignItems: 'start'\n        }\n      }\n    }\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    id: 'aa',\n    className: 'full-width-grid'\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.DetailsList, {\n    isHeaderVisible: true,\n    layoutMode: _fluentui_react__WEBPACK_IMPORTED_MODULE_1__.DetailsListLayoutMode.justified,\n    items: items,\n    columns: colums,\n    selectionPreservedOnEmptyClick: true,\n    selectionMode: _fluentui_react__WEBPACK_IMPORTED_MODULE_1__.SelectionMode.multiple,\n    selection: selection,\n    onRenderRow: renderRow,\n    onRenderItemColumn: renderItemColumn,\n    onItemInvoked: onItemInvoke,\n    dragDropEvents: onDragRowItem(),\n    styles: gridStyles\n  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: {\n      \"float\": \"left\",\n      \"width\": \"50%\"\n    }\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.PrimaryButton, {\n    id: \"updateorder\",\n    text: \"Update Order\",\n    onClick: onClickReorderButton(\"updateorder\"),\n    style: {\n      \"padding\": \"1px\"\n    }\n  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.PrimaryButton, {\n    id: \"addnew\",\n    text: \"Add New\",\n    onClick: onClickReorderButton(\"addnew\"),\n    style: {\n      \"margin\": \"0px 2px 0px 2px\",\n      \"padding\": \"1px\"\n    }\n  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.PrimaryButton, {\n    id: \"delete\",\n    text: \"Delete\",\n    disabled: !((selectedRecords === null || selectedRecords === void 0 ? void 0 : selectedRecords.length) > 0),\n    onClick: onClickReorderButton(\"delete\"),\n    style: {\n      \"padding\": \"1px\"\n    }\n  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: {\n      \"float\": \"right\",\n      \"width\": \"50%\"\n    }\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.PrimaryButton, {\n    id: \"loadnextpage\",\n    disabled: !(dataSet === null || dataSet === void 0 ? void 0 : dataSet.paging.hasNextPage),\n    text: \"Load Next Page\",\n    onClick: onClickReorderButton(\"loadnextpage\"),\n    style: {\n      \"float\": \"right\",\n      \"margin\": \"0px 0px 0px 10px\",\n      \"padding\": \"1px\"\n    }\n  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"p\", {\n    style: {\n      \"float\": \"right\"\n    }\n  }, \"Loaded: \", [items.length], \" / \", [dataSet === null || dataSet === void 0 ? void 0 : dataSet.paging.totalResultCount], \" \"))));\n});\nsortDataSet.displayName = sortDataSet.displayName ? sortDataSet.displayName : \"sortDataSet\";\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./OrderLineItems/SortDataSet.tsx?");

/***/ }),

/***/ "./OrderLineItems/index.ts":
/*!*********************************!*\
  !*** ./OrderLineItems/index.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   OrderLineItems: () => (/* binding */ OrderLineItems)\n/* harmony export */ });\n/* harmony import */ var _SortDataSet__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SortDataSet */ \"./OrderLineItems/SortDataSet.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\nvar __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {\n  function adopt(value) {\n    return value instanceof P ? value : new P(function (resolve) {\n      resolve(value);\n    });\n  }\n  return new (P || (P = Promise))(function (resolve, reject) {\n    function fulfilled(value) {\n      try {\n        step(generator.next(value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n    function rejected(value) {\n      try {\n        step(generator[\"throw\"](value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n    function step(result) {\n      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);\n    }\n    step((generator = generator.apply(thisArg, _arguments || [])).next());\n  });\n};\n\n\nclass OrderLineItems {\n  /**\r\n   * Empty constructor.\r\n   */\n  constructor() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  init(context, notifyOutputChanged, state) {\n    \"use strict\";\n\n    return __awaiter(this, void 0, void 0, function* () {\n      this.notifyOutputChanged = notifyOutputChanged;\n      this.entityType = context.parameters.DataSet.getTargetEntityType();\n      this.sequenceColumnTarget = context.parameters.DataSet.columns.find(column => column.alias === \"OrderColumn\");\n      this.optionSetColorDefined = context.parameters.DataSet.columns.find(column => column.alias === \"OptionSetColorDefined\");\n      // Method for set all varaibles that handled in Async operation, and call the updateView method\n      this.SetVariableValues();\n    });\n  }\n  SetVariableValues() {\n    \"use strict\";\n\n    return __awaiter(this, void 0, void 0, function* () {\n      this.optionSetColorDefinedMetadata = yield this.GetAttributeMetadata(this.entityType, this.optionSetColorDefined.name);\n      this.getOutputs();\n    });\n  }\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  updateView(context) {\n    \"use strict\";\n\n    var props = {\n      dataSet: context.parameters.DataSet,\n      sequenceColumn: this.sequenceColumnTarget,\n      optionSetMetadata: this.optionSetColorDefinedMetadata,\n      optionSetColumn: this.optionSetColorDefined\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_SortDataSet__WEBPACK_IMPORTED_MODULE_0__.sortDataSet, props);\n  }\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\r\n   */\n  getOutputs() {\n    \"use strict\";\n\n    return {};\n  }\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  destroy() {\n    \"use strict\";\n\n    // Add code to cleanup control if necessary\n  }\n  GetAttributeMetadata(entityLogicName, attributeLoficalName) {\n    \"use strict\";\n\n    return new Promise(function (resolve, reject) {\n      if (entityLogicName === null || attributeLoficalName === null) {\n        resolve(null);\n      } else {\n        var OptionMetaData = [null];\n        var Utility = Xrm.Utility;\n        var globalContext = Utility.getGlobalContext();\n        var serverURL = globalContext.getClientUrl();\n        var Query = \"EntityDefinitions(LogicalName='\" + entityLogicName + \"')/Attributes(LogicalName='\" + attributeLoficalName + \"')/Microsoft.Dynamics.CRM.PicklistAttributeMetadata?$select=LogicalName&$expand=OptionSet($select=Options)\";\n        var req = new XMLHttpRequest();\n        req.open(\"GET\", serverURL + \"/api/data/v9.2/\" + Query, true);\n        req.setRequestHeader(\"Accept\", \"application/json\");\n        req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n        req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n        req.setRequestHeader(\"OData-Version\", \"4.0\");\n        req.setRequestHeader(\"Prefer\", \"odata.include-annotations=*\");\n        req.onreadystatechange = () => __awaiter(this, void 0, void 0, function* () {\n          \"use strict\";\n\n          if (req.readyState === 4 /* complete */) {\n            req.onreadystatechange = null;\n            if (req.status === 200) {\n              var data = JSON.parse(req.response);\n              if (data !== null && data.OptionSet !== null && data.OptionSet !== undefined) {\n                data.OptionSet.Options.forEach(option => {\n                  OptionMetaData.push({\n                    value: option.Value,\n                    label: option.Label.UserLocalizedLabel.Label,\n                    color: option.Color\n                  });\n                });\n                OptionMetaData.shift();\n                resolve(OptionMetaData);\n              }\n            }\n          }\n        });\n        req.send();\n      }\n    });\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./OrderLineItems/index.ts?");

/***/ }),

/***/ "@fluentui/react":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
/***/ ((module) => {

module.exports = Reactv16;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./OrderLineItems/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Dynamics.OrderLineItems', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.OrderLineItems);
} else {
	var Dynamics = Dynamics || {};
	Dynamics.OrderLineItems = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.OrderLineItems;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}